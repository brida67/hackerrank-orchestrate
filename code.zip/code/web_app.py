import os
import sys
import json
import base64
import zipfile
from datetime import date
from flask import Flask, render_template, jsonify, request, send_file, send_from_directory
import pandas as pd

# Add code directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)
from financial_engine import FinancialDecisionEngine, IMAGE_AMOUNTS
from llm_intent import extract_intent, format_decision_reply
from bank_connector import PlaidConnector, build_live_profile

app = Flask(__name__, template_folder=os.path.join(current_dir, 'templates'), static_folder=os.path.join(current_dir, 'static'))

repo_root = os.path.abspath(os.path.join(current_dir, '..'))
dataset_dir = os.path.join(repo_root, 'dataset')
engine = FinancialDecisionEngine(data_dir=dataset_dir)

# Load cached predictions
output_path = os.path.join(repo_root, 'output.csv')
if os.path.exists(output_path):
    output_df = pd.read_csv(output_path)
else:
    output_df = None

sample_df = pd.read_csv(os.path.join(dataset_dir, 'sample_requests.csv'))
requests_df = pd.read_csv(os.path.join(dataset_dir, 'requests.csv'))
profiles_df = pd.read_csv(os.path.join(dataset_dir, 'financial_profiles.csv'))
images_meta_df = pd.read_csv(os.path.join(dataset_dir, 'images.csv'))
messages_df = pd.read_csv(os.path.join(dataset_dir, 'messages.csv'))
options_df = pd.read_csv(os.path.join(dataset_dir, 'request_payment_options.csv'))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/stats')
def get_stats():
    global output_df
    if output_df is None and os.path.exists(output_path):
        output_df = pd.read_csv(output_path)
        
    stats = {
        'total_requests': len(requests_df),
        'sample_requests': len(sample_df),
        'total_users': len(profiles_df),
        'multimodal_images': len(IMAGE_AMOUNTS),
        'deadline': '2026-09-13T18:00:00+05:30',
        'submission_url': 'https://www.hackerrank.com/contests/hackerrank-orchestrate-september26/challenges/buy-or-wait/submission'
    }
    if output_df is not None:
        stats['status_dist'] = output_df['affordability_status'].value_counts().to_dict()
        stats['method_dist'] = output_df['recommended_payment_method'].value_counts().to_dict()
    return jsonify(stats)

@app.route('/api/requests')
def list_requests():
    global output_df
    if output_df is None and os.path.exists(output_path):
        output_df = pd.read_csv(output_path)

    # Merge requests with output predictions
    merged_eval = pd.merge(requests_df, output_df, on='request_id')
    merged_eval['is_sample'] = False
    
    sample_sub = sample_df.copy()
    sample_sub['is_sample'] = True
    
    combined = pd.concat([sample_sub, merged_eval], ignore_index=True)
    
    # Return compact summary list
    summary_list = []
    for _, r in combined.iterrows():
        summary_list.append({
            'request_id': r['request_id'],
            'user_id': r['user_id'],
            'request_date': r['request_date'],
            'request_type': r['request_type'],
            'requested_amount': float(r['requested_amount']),
            'amount_safe_to_pay': float(r['amount_safe_to_pay']),
            'affordability_status': r['affordability_status'],
            'recommended_payment_method': r['recommended_payment_method'],
            'is_sample': bool(r['is_sample']),
            'request_text': r['request_text']
        })
    return jsonify(summary_list)

@app.route('/api/request/<req_id>')
def get_request_detail(req_id):
    # Check if in sample or eval
    is_sample = False
    req_row = None
    pred_row = None
    
    if req_id in sample_df['request_id'].values:
        req_row = sample_df[sample_df['request_id'] == req_id].iloc[0]
        is_sample = True
        pred_dict = {
            'amount_safe_to_pay': float(req_row['amount_safe_to_pay']),
            'affordability_status': req_row['affordability_status'],
            'recommended_payment_method': req_row['recommended_payment_method'],
            'payment_plan': req_row['payment_plan'],
            'earliest_date_for_full_payment': str(req_row['earliest_date_for_full_payment']) if pd.notna(req_row['earliest_date_for_full_payment']) else '',
            'spending_changes_needed': req_row['spending_changes_needed'],
            'decision_explanation': req_row['decision_explanation']
        }
    else:
        req_row = requests_df[requests_df['request_id'] == req_id].iloc[0]
        pred_dict = engine.evaluate_request(req_row)

    user_id = req_row['user_id']
    prof = profiles_df[profiles_df['user_id'] == user_id].iloc[0].to_dict()
    for k, v in prof.items():
        if pd.isna(v):
            prof[k] = None

    # Simulate 90-day trajectory
    traj = engine.simulate_cash_flow(user_id, req_row['request_date'])
    
    # Calculate with-purchase balance curve
    with_plan_balances = list(traj['balances'])
    method = pred_dict['recommended_payment_method']
    plan_str = pred_dict['payment_plan']
    
    if plan_str and plan_str != 'none':
        payments = []
        for p in plan_str.split('|'):
            p_date, p_amt = p.split(':')
            payments.append((p_date, float(p_amt)))
            
        # Deduct payments
        dates_list = traj['dates']
        for p_date, p_amt in payments:
            if p_date in dates_list:
                p_idx = dates_list.index(p_date)
                for idx in range(p_idx, len(with_plan_balances)):
                    with_plan_balances[idx] -= p_amt

    # Payment options
    req_opts = options_df[options_df['request_id'] == req_id].to_dict(orient='records')
    for opt in req_opts:
        for k, v in opt.items():
            if pd.isna(v):
                opt[k] = None

    # Messages
    u_msgs = messages_df[messages_df['user_id'] == user_id].to_dict(orient='records')
    for m in u_msgs:
        for k, v in m.items():
            if pd.isna(v):
                m[k] = None

    # Image links
    linked_imgs = images_meta_df[images_meta_df['user_id'] == user_id].to_dict(orient='records')
    for img in linked_imgs:
        eid = img['related_event_id']
        img['verified_amount'] = IMAGE_AMOUNTS.get(eid, None)
        img['image_url'] = f"/media/images/{img['image_id']}.png"

    response = {
        'request': {
            'request_id': req_id,
            'user_id': user_id,
            'request_date': req_row['request_date'],
            'request_type': req_row['request_type'],
            'requested_amount': float(req_row['requested_amount']),
            'desired_completion_date': req_row['desired_completion_date'],
            'allows_partial_payment': bool(req_row['allows_partial_payment']),
            'request_text': req_row['request_text'],
            'is_sample': is_sample
        },
        'prediction': pred_dict,
        'profile': prof,
        'trajectory': {
            'dates': traj['dates'],
            'baseline_balances': traj['balances'],
            'with_plan_balances': with_plan_balances,
            'min_balance': traj['min_balance'],
            'init_balance': traj['init_balance'],
            'currency': traj['currency'],
            'events_log': {k.strftime('%Y-%m-%d'): v for k, v in traj['events_log'].items() if len(v) > 0}
        },
        'payment_options': req_opts,
        'messages': u_msgs,
        'linked_images': linked_imgs
    }
    return jsonify(response)

@app.route('/api/simulate', methods=['POST'])
def simulate_scenario():
    data = request.json or {}
    user_id = data.get('user_id', 'user_01')
    req_date = data.get('request_date', '2024-03-03')
    req_amount = float(data.get('requested_amount', 10000.0))
    desired_date = data.get('desired_completion_date', '2024-04-01')
    allows_partial = bool(data.get('allows_partial_payment', True))
    
    # Custom spending changes
    spending_changes = data.get('spending_changes', {})
    
    # Run simulation
    traj = engine.simulate_cash_flow(user_id, req_date, spending_changes=spending_changes)
    
    # Evaluate
    mock_row = pd.Series({
        'request_id': 'sim_custom',
        'user_id': user_id,
        'request_date': req_date,
        'requested_amount': req_amount,
        'desired_completion_date': desired_date,
        'allows_partial_payment': allows_partial,
        'request_text': 'What-If custom simulation'
    })
    pred = engine.evaluate_request(mock_row)
    
    return jsonify({
        'prediction': pred,
        'trajectory': {
            'dates': traj['dates'],
            'balances': traj['balances'],
            'min_balance': traj['min_balance'],
            'init_balance': traj['init_balance'],
            'currency': traj['currency']
        }
    })

@app.route('/api/images/<image_id>')
def get_image_info(image_id):
    img_row = images_meta_df[images_meta_df['image_id'] == image_id]
    if len(img_row) == 0:
        return jsonify({'error': 'Image not found'}), 404
    r = img_row.iloc[0].to_dict()
    eid = r['related_event_id']
    r['verified_amount'] = IMAGE_AMOUNTS.get(eid, None)
    r['image_url'] = f"/media/images/{image_id}.png"
    return jsonify(r)

@app.route('/media/images/<path:filename>')
def serve_media_image(filename):
    media_dir = os.path.join(dataset_dir, 'media', 'images')
    return send_from_directory(media_dir, filename)

@app.route('/api/export_zip')
def export_code_zip():
    zip_path = os.path.join(repo_root, 'code.zip')
    # Build zip file containing code/, evaluation/, README.md
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        # Add code directory
        for root, dirs, files in os.walk(current_dir):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, repo_root)
                zf.write(full_path, rel_path)
                
        # Add README.md
        readme_path = os.path.join(repo_root, 'README.md')
        if os.path.exists(readme_path):
            zf.write(readme_path, 'README.md')
            
        # Add AGENTS.md
        agents_path = os.path.join(repo_root, 'AGENTS.md')
        if os.path.exists(agents_path):
            zf.write(agents_path, 'AGENTS.md')
            
        # Add evaluation/usage_report.md
        eval_report = os.path.join(current_dir, 'evaluation', 'usage_report.md')
        if os.path.exists(eval_report):
            zf.write(eval_report, 'evaluation/usage_report.md')
            
    return send_file(zip_path, as_attachment=True, download_name='code.zip')

@app.route('/api/download_output')
def download_output():
    if os.path.exists(output_path):
        return send_file(output_path, as_attachment=True, download_name='output.csv')
    return jsonify({'error': 'output.csv does not exist'}), 404

# ─── Plan B: Chat endpoint ───────────────────────────────────────────────────

@app.route('/api/chat', methods=['POST'])
def chat():
    """Natural language chat endpoint — accepts free-text, returns decision."""
    data = request.json or {}
    message = data.get('message', '').strip()
    user_id = data.get('user_id', 'user_01')

    if not message:
        return jsonify({'error': 'No message provided'}), 400

    # Look up user currency from profile
    user_currency = 'INR'
    prof_rows = profiles_df[profiles_df['user_id'] == user_id]
    if len(prof_rows) > 0:
        user_currency = prof_rows.iloc[0].get('currency', 'INR')

    # Extract intent from natural language
    intent = extract_intent(message, user_currency=user_currency)

    # If we need a follow-up, return the question
    if intent.get('follow_up_needed'):
        return jsonify({
            'type': 'follow_up',
            'question': intent['follow_up_question'],
            'intent': intent
        })

    # Build a mock request row and evaluate
    req_date = intent.get('desired_date') or str(date.today())
    amount = intent.get('amount') or 0.0

    mock_row = pd.Series({
        'request_id': 'chat_query',
        'user_id': user_id,
        'request_date': req_date,
        'requested_amount': amount,
        'desired_completion_date': intent.get('desired_date') or req_date,
        'allows_partial_payment': intent.get('allows_partial', True),
        'request_text': message
    })

    prediction = engine.evaluate_request(mock_row)
    trajectory = engine.simulate_cash_flow(user_id, req_date)
    reply = format_decision_reply(prediction, intent)

    return jsonify({
        'type': 'decision',
        'reply': reply,
        'intent': intent,
        'prediction': prediction,
        'trajectory': {
            'dates': trajectory['dates'],
            'balances': trajectory['balances'],
            'min_balance': trajectory['min_balance'],
            'currency': trajectory['currency']
        }
    })


@app.route('/api/ocr_receipt', methods=['POST'])
def ocr_receipt():
    """Extract amount/merchant from a base64-encoded receipt image."""
    data = request.json or {}
    image_b64 = data.get('image_base64', '')

    if not image_b64:
        return jsonify({'error': 'No image_base64 provided'}), 400

    # Try Google Cloud Vision if credentials set, else use mock
    gcv_key = os.environ.get('GOOGLE_CLOUD_VISION_API_KEY')
    result = None

    if gcv_key:
        try:
            import urllib.request as urlreq
            payload = json.dumps({
                'requests': [{
                    'image': {'content': image_b64},
                    'features': [{'type': 'TEXT_DETECTION'}]
                }]
            }).encode()
            req = urlreq.Request(
                f'https://vision.googleapis.com/v1/images:annotate?key={gcv_key}',
                data=payload,
                headers={'Content-Type': 'application/json'}
            )
            r = urlreq.urlopen(req)
            vision_data = json.loads(r.read())
            raw_text = vision_data['responses'][0].get('fullTextAnnotation', {}).get('text', '')
            # Use LLM intent to parse the OCR text
            extracted = extract_intent(f"Receipt text: {raw_text}")
            result = {
                'amount': extracted.get('amount'),
                'currency': extracted.get('currency'),
                'merchant': extracted.get('item_description', 'Unknown'),
                'date': str(date.today()),
                '_source': 'google_cloud_vision'
            }
        except Exception as e:
            result = None

    if not result:
        # Mock extraction for demo
        result = {
            'amount': 4500.00,
            'currency': 'INR',
            'merchant': 'Sample Merchant (mock — set GOOGLE_CLOUD_VISION_API_KEY for real OCR)',
            'date': str(date.today()),
            '_source': 'mock'
        }

    return jsonify(result)


# ─── Plan A: Bank connection endpoints ───────────────────────────────────────

_plaid = PlaidConnector()

@app.route('/connect/bank')
def bank_connect_init():
    """Step 1: Generate Plaid Link token."""
    user_id = request.args.get('user_id', 'user_demo')
    link_data = _plaid.create_link_token(user_id)
    return jsonify(link_data)


@app.route('/connect/bank/callback', methods=['POST'])
def bank_connect_callback():
    """Step 2: Exchange public_token for access_token and build live profile."""
    data = request.json or {}
    public_token = data.get('public_token', '')
    user_id = data.get('user_id', 'user_demo')

    if not public_token:
        return jsonify({'error': 'public_token required'}), 400

    access_token = _plaid.exchange_public_token(public_token)
    live_profile = build_live_profile(user_id, access_token, provider='plaid')

    return jsonify({
        'status': 'connected',
        'profile_summary': {
            'available_balance': live_profile['current_available_balance'],
            'currency': live_profile['currency'],
            'salary': live_profile['monthly_salary'],
            'recurring_expenses': len(live_profile['monthly_fixed_commitments']),
            'source': live_profile.get('_source', 'plaid')
        }
    })


@app.route('/api/live_profile')
def live_profile():
    """Demo: build and return a live profile using mock Plaid data."""
    user_id = request.args.get('user_id', 'user_demo')
    profile = build_live_profile(user_id, 'mock-access-token', provider='plaid')
    return jsonify(profile)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting Buy or Wait? AI Financial Hub on http://127.0.0.1:{port}")
    app.run(host='127.0.0.1', port=port, debug=False)
