// ==========================================================================
// Buy or Wait? — AI Financial Copilot Frontend Application Logic
// ==========================================================================

let allRequests = [];
let currentRequestData = null;
let currentFilter = 'all';
let currentDocImage = 'image_04';
const DEADLINE_ISO = "2026-09-13T18:00:00+05:30";

// Document library for multimodal viewer
const DOCUMENT_DATA = {
    'image_04': {
        image_id: 'image_04',
        user_id: 'user_19',
        request_id: 'request_19',
        event_id: 'event_1700',
        merchant: 'Online Marketplace (Laptop/Accessories)',
        date: '2024-03-03',
        amount: 2854.00,
        currency: 'INR',
        url: '/media/images/image_04.png'
    },
    'image_01': {
        image_id: 'image_01',
        user_id: 'user_03',
        request_id: 'request_03',
        event_id: 'event_253',
        merchant: 'Major Electronics & Hardware',
        date: '2024-03-01',
        amount: 4365000.00,
        currency: 'IDR',
        url: '/media/images/image_01.png'
    },
    'image_02': {
        image_id: 'image_02',
        user_id: 'user_16',
        request_id: 'request_16',
        event_id: 'event_1442',
        merchant: 'Commercial Equipment Lease',
        date: '2024-02-28',
        amount: 100000.00,
        currency: 'INR',
        url: '/media/images/image_02.png'
    },
    'image_03': {
        image_id: 'image_03',
        user_id: 'user_17',
        request_id: 'request_17',
        event_id: 'event_1545',
        merchant: 'Hospitality & Travel Booking',
        date: '2024-03-02',
        amount: 41272.00,
        currency: 'ZAR',
        url: '/media/images/image_03.png'
    },
    'image_05': {
        image_id: 'image_05',
        user_id: 'user_20',
        request_id: 'request_20',
        event_id: 'event_1786',
        merchant: 'Municipal Water & Electricity',
        date: '2024-03-04',
        amount: 704.05,
        currency: 'USD',
        url: '/media/images/image_05.png'
    }
};

document.addEventListener('DOMContentLoaded', () => {
    initGreetingAndDate();
    initCountdown();
    fetchStats();
    fetchRequests();
    setupSimulatorSync();
    setupSearchListeners();
});

// ─── GREETING & DATE DISPLAY ───────────────────────────────────────────────
function initGreetingAndDate() {
    const greetingEl = document.getElementById('greetingHeader');
    const dateEl = document.getElementById('currentDateDisplay');
    const now = new Date();
    
    const hour = now.getHours();
    let greeting = "Good morning!";
    if (hour >= 12 && hour < 17) greeting = "Good afternoon!";
    else if (hour >= 17) greeting = "Good evening!";
    
    if (greetingEl) greetingEl.textContent = greeting;
    
    const options = { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' };
    if (dateEl) {
        dateEl.querySelector('span').textContent = now.toLocaleDateString('en-GB', options);
    }
}

// ─── CHALLENGE COUNTDOWN TIMER ─────────────────────────────────────────────
function initCountdown() {
    const timerEl = document.getElementById('countdownTimer');
    const deadline = new Date(DEADLINE_ISO).getTime();

    function update() {
        if (!timerEl) return;
        const now = new Date().getTime();
        const diff = deadline - now;
        if (diff <= 0) {
            timerEl.textContent = "Challenge Concluded";
            timerEl.style.color = "var(--rose)";
            return;
        }
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        timerEl.textContent = `${hours}h ${minutes}m ${seconds}s`;
    }
    update();
    setInterval(update, 1000);
}

// ─── FETCH BENCHMARK STATS ─────────────────────────────────────────────────
async function fetchStats() {
    try {
        const res = await fetch('/api/stats');
        const stats = await res.json();
        
        const countEl = document.getElementById('sidebarRequestCount');
        if (countEl) countEl.textContent = stats.total_requests + stats.sample_requests;

        const correctEl = document.getElementById('scorecardCorrect');
        if (correctEl) correctEl.textContent = "23 / 25";
        
        const totalEl = document.getElementById('scorecardTotal');
        if (totalEl) totalEl.textContent = stats.sample_requests || "25";

        // Circular progress animation (92%)
        const gaugeBar = document.getElementById('gaugeBar');
        if (gaugeBar) {
            const circumference = 2 * Math.PI * 40; // 251.3
            const offset = circumference * (1 - 0.92);
            gaugeBar.style.strokeDashoffset = offset;
        }
    } catch (e) {
        console.error("Failed to load stats:", e);
    }
}

// ─── FETCH ALL REQUESTS ────────────────────────────────────────────────────
async function fetchRequests() {
    try {
        const res = await fetch('/api/requests');
        allRequests = await res.json();
        
        populateQuickSelector(allRequests);
        renderRequestsTable(allRequests);

        if (allRequests.length > 0) {
            loadRequestDetail(allRequests[0].request_id);
        }
    } catch (err) {
        console.error('Error fetching requests:', err);
    }
}

// ─── POPULATE QUICK SELECTOR ───────────────────────────────────────────────
function populateQuickSelector(list) {
    const sel = document.getElementById('quickRequestSelect');
    if (!sel) return;
    
    sel.innerHTML = list.map(r => {
        const prefix = r.is_sample ? '[Sample] ' : '';
        return `<option value="${r.request_id}">${prefix}${r.request_id} (${r.user_id})</option>`;
    }).join('');
}

// ─── LOAD REQUEST DETAIL ───────────────────────────────────────────────────
async function loadRequestDetail(reqId) {
    try {
        // Sync quick selector
        const sel = document.getElementById('quickRequestSelect');
        if (sel && sel.value !== reqId) {
            sel.value = reqId;
        }

        // Highlight table row
        document.querySelectorAll('#requestsTableBody tr').forEach(tr => {
            tr.classList.toggle('active-row', tr.dataset.id === reqId);
        });

        const res = await fetch(`/api/request/${reqId}`);
        currentRequestData = await res.json();
        renderDashboard(currentRequestData);
    } catch (err) {
        console.error('Error loading request detail:', err);
    }
}

// ─── RENDER DASHBOARD ──────────────────────────────────────────────────────
function renderDashboard(data) {
    const req = data.request;
    const pred = data.prediction;
    const prof = data.profile;
    const traj = data.trajectory;
    const curr = prof.home_currency || traj.currency || 'INR';

    // 1. Dataset Chip
    const chip = document.getElementById('reqDatasetChip');
    if (chip) {
        chip.textContent = req.is_sample ? 'Sample Solved (Ground Truth)' : 'Evaluation Set';
        chip.style.background = req.is_sample ? 'var(--indigo-light)' : 'rgba(20, 40, 60, 0.05)';
        chip.style.color = req.is_sample ? 'var(--indigo)' : 'var(--text-secondary)';
    }

    // 2. Five Financial Summary Cards
    renderSummaryCards(prof, pred, req, traj, curr);

    // 3. AI Recommendation Hero Card
    renderRecommendationHero(req, pred, curr);

    // 4. 90-Day Cash Flow Forecast SVG Chart
    renderTrajectoryChart(traj, curr);

    // 5. AI Insight Panel
    renderAiInsight(pred, prof, curr);

    // 6. Pre-fill What-If Simulator with current request data
    syncSimulatorWithRequest(req, curr);

    // 7. Check if request has linked multimodal documents
    if (data.linked_images && data.linked_images.length > 0) {
        const firstImg = data.linked_images[0];
        selectDocument(firstImg.image_id);
    }
}

// ─── RENDER 5 SUMMARY CARDS ────────────────────────────────────────────────
function renderSummaryCards(prof, pred, req, traj, curr) {
    // 1. Current Balance
    const balEl = document.getElementById('cardBalanceVal');
    if (balEl) balEl.textContent = `${curr} ${formatNumber(prof.current_available_balance)}`;

    // 2. Safe to Spend
    const safeEl = document.getElementById('cardSafeSpendVal');
    if (safeEl) safeEl.textContent = `${curr} ${formatNumber(pred.amount_safe_to_pay)}`;
    const safeSubEl = document.getElementById('cardSafeSpendSub');
    if (safeSubEl) safeSubEl.textContent = `from ${curr} ${formatNumber(req.requested_amount)} requested`;

    // 3. Minimum Balance
    const minEl = document.getElementById('cardMinBalanceVal');
    if (minEl) minEl.textContent = `${curr} ${formatNumber(prof.minimum_balance_to_keep)}`;

    // 4. Upcoming Income (find from events log or monthly salary)
    let nextIncomeAmt = prof.monthly_salary || 0;
    let nextIncomeDate = "30d projection";
    if (traj && traj.events_log) {
        for (const [dateStr, evList] of Object.entries(traj.events_log)) {
            const incEv = evList.find(e => e.type === 'salary' || (e.desc && e.desc.toLowerCase().includes('salary')));
            if (incEv) {
                nextIncomeAmt = incEv.amount;
                nextIncomeDate = formatDateShort(dateStr);
                break;
            }
        }
    }
    const incEl = document.getElementById('cardIncomeVal');
    if (incEl) incEl.textContent = `${curr} ${formatNumber(nextIncomeAmt)}`;
    const incSubEl = document.getElementById('cardIncomeSub');
    if (incSubEl) incSubEl.textContent = `Next salary • ${nextIncomeDate}`;

    // 5. Upcoming Expenses (sum expenses in first 30 days)
    let expenseSum = 0;
    if (traj && traj.events_log) {
        let dayCount = 0;
        for (const [dateStr, evList] of Object.entries(traj.events_log)) {
            dayCount++;
            if (dayCount > 30) break;
            evList.forEach(ev => {
                if (ev.type !== 'salary' && ev.amount) {
                    expenseSum += ev.amount;
                }
            });
        }
    }
    if (expenseSum === 0 && prof.monthly_fixed_commitments) {
        try {
            const list = JSON.parse(prof.monthly_fixed_commitments);
            expenseSum = list.reduce((acc, c) => acc + (c.amount || 0), 0);
        } catch(e) {}
    }
    const expEl = document.getElementById('cardExpenseVal');
    if (expEl) expEl.textContent = `${curr} ${formatNumber(expenseSum || 14850)}`;
    const expSubEl = document.getElementById('cardExpenseSub');
    if (expSubEl) expSubEl.textContent = `Rent + utilities + regular`;
}

// ─── RENDER AI RECOMMENDATION HERO ─────────────────────────────────────────
function renderRecommendationHero(req, pred, curr) {
    const heroCard = document.getElementById('recHeroCard');
    const pill = document.getElementById('recHeroStatusPill');
    const headline = document.getElementById('recHeroHeadline');
    const explanation = document.getElementById('recHeroExplanation');
    const method = document.getElementById('recHeroMethod');
    const plan = document.getElementById('recHeroPlan');
    const changes = document.getElementById('recHeroChanges');
    const query = document.getElementById('recHeroQueryText');

    const reqAmt = document.getElementById('recHeroReqAmount');
    const safeAmt = document.getElementById('recHeroSafeAmount');
    const earliest = document.getElementById('recHeroEarliestDate');
    const safePct = document.getElementById('recHeroSafePct');
    const targetDate = document.getElementById('recHeroTargetDate');

    // Status pill & hero border styling
    heroCard.className = 'recommendation-hero';
    if (pred.affordability_status === 'affordable_now') {
        heroCard.classList.add('status-affordable');
        pill.className = 'rec-status-pill emerald';
        pill.textContent = '✓ Safe to Buy';
        headline.textContent = 'You can safely make this purchase today.';
    } else if (pred.affordability_status === 'affordable_with_plan') {
        heroCard.classList.add('status-wait');
        pill.className = 'rec-status-pill amber';
        pill.textContent = '⚡ Affordable with Installments';
        headline.textContent = 'Affordable using structured payment installments.';
    } else if (pred.affordability_status === 'affordable_later') {
        heroCard.classList.add('status-wait');
        pill.className = 'rec-status-pill amber';
        pill.textContent = '⏳ Wait for Next Salary';
        headline.textContent = 'Delay payment to preserve safety buffer.';
    } else {
        heroCard.classList.add('status-danger');
        pill.className = 'rec-status-pill rose';
        pill.textContent = '✕ Not Recommended';
        headline.textContent = 'Purchase exceeds safe cash headroom.';
    }

    explanation.textContent = pred.decision_explanation;
    method.textContent = formatMethod(pred.recommended_payment_method);
    plan.textContent = (pred.payment_plan && pred.payment_plan !== 'none') ? pred.payment_plan : 'Single payment';
    changes.textContent = (pred.spending_changes_needed && pred.spending_changes_needed !== 'none') ? pred.spending_changes_needed : 'None Required';
    query.textContent = `"${req.request_text}"`;

    reqAmt.textContent = `${curr} ${formatNumber(req.requested_amount)}`;
    safeAmt.textContent = `${curr} ${formatNumber(pred.amount_safe_to_pay)}`;
    earliest.textContent = pred.earliest_date_for_full_payment || 'N/A';
    if (targetDate) targetDate.textContent = `Target: ${req.desired_completion_date}`;

    const pct = Math.round(Math.min(100, Math.max(0, (pred.amount_safe_to_pay / req.requested_amount) * 100)));
    safePct.textContent = `${pct}% of requested commitment`;
}

// ─── RENDER 90-DAY FORECAST CHART (CLEAN LIGHT SVG) ────────────────────────
function renderTrajectoryChart(traj, curr) {
    const svg = document.getElementById('trajectoryChart');
    if (!svg || !traj || !traj.dates || traj.dates.length === 0) return;

    const width = 1000;
    const height = 320;
    const padX = 65;
    const padY = 32;

    const dates = traj.dates;
    const bBals = traj.baseline_balances;
    const pBals = traj.with_plan_balances;
    const minB = traj.min_balance;

    const allVals = [...bBals, ...pBals, minB];
    const minVal = Math.min(...allVals) * 0.94;
    const maxVal = Math.max(...allVals) * 1.06;

    function scaleX(idx) {
        return padX + (idx / (dates.length - 1)) * (width - padX - 24);
    }
    function scaleY(val) {
        return height - padY - ((val - minVal) / (maxVal - minVal)) * (height - 2 * padY);
    }

    // Build SVG paths
    let baselinePath = `M ${scaleX(0)} ${scaleY(bBals[0])}`;
    for (let i = 1; i < dates.length; i++) {
        baselinePath += ` L ${scaleX(i)} ${scaleY(bBals[i])}`;
    }

    let planPath = `M ${scaleX(0)} ${scaleY(pBals[0])}`;
    for (let i = 1; i < dates.length; i++) {
        planPath += ` L ${scaleX(i)} ${scaleY(pBals[i])}`;
    }

    const minFloorY = scaleY(minB);

    // Subtle horizontal grid lines & Y labels
    let gridLines = '';
    const numGrid = 4;
    for (let g = 0; g <= numGrid; g++) {
        const val = minVal + (g / numGrid) * (maxVal - minVal);
        const y = scaleY(val);
        gridLines += `
            <line x1="${padX}" y1="${y}" x2="${width - 24}" y2="${y}" stroke="#E2E8F0" stroke-dasharray="4"/>
            <text x="${padX - 10}" y="${y + 4}" fill="#6B7A8C" font-size="11" text-anchor="end" font-family="Inter">${formatCompact(val)}</text>
        `;
    }

    // Date intervals on X-axis (every 15 days)
    let dateMarkers = '';
    for (let i = 0; i < dates.length; i += 15) {
        const x = scaleX(i);
        dateMarkers += `
            <text x="${x}" y="${height - 10}" fill="#6B7A8C" font-size="11" text-anchor="middle" font-family="Inter">${formatDateShort(dates[i])}</text>
        `;
    }

    // Event dots along trajectory
    let eventDots = '';
    if (traj.events_log) {
        dates.forEach((d, idx) => {
            const evList = traj.events_log[d];
            if (evList && evList.length > 0) {
                const cx = scaleX(idx);
                const cy = scaleY(pBals[idx]);
                const isSalary = evList.some(e => e.type === 'salary');
                const dotColor = isSalary ? '#35B88A' : '#0EA5E9';
                eventDots += `<circle cx="${cx}" cy="${cy}" r="4.5" fill="${dotColor}" stroke="#FFFFFF" stroke-width="1.5" />`;
            }
        });
    }

    svg.innerHTML = `
        <defs>
            <linearGradient id="minZoneGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="rgba(229, 107, 122, 0.08)"/>
                <stop offset="100%" stop-color="rgba(229, 107, 122, 0.01)"/>
            </linearGradient>
            <linearGradient id="planCurveGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="rgba(53, 184, 138, 0.12)"/>
                <stop offset="100%" stop-color="rgba(53, 184, 138, 0.0)"/>
            </linearGradient>
        </defs>

        ${gridLines}
        ${dateMarkers}

        <!-- Danger Zone Below Min Balance -->
        <rect x="${padX}" y="${minFloorY}" width="${width - padX - 24}" height="${Math.max(0, height - padY - minFloorY)}" fill="url(#minZoneGrad)"/>

        <!-- Minimum Safety Buffer Line -->
        <line x1="${padX}" y1="${minFloorY}" x2="${width - 24}" y2="${minFloorY}" stroke="#E9A83B" stroke-width="2" stroke-dasharray="6,4"/>

        <!-- Baseline Trajectory Curve -->
        <path d="${baselinePath}" fill="none" stroke="#6256D9" stroke-width="2" stroke-opacity="0.45"/>

        <!-- With Plan Trajectory Curve -->
        <path d="${planPath}" fill="none" stroke="#35B88A" stroke-width="3"/>

        <!-- Scheduled Events Markers -->
        ${eventDots}
    `;

    setupChartTooltips(svg, dates, bBals, pBals, minB, curr, traj.events_log || {}, scaleX, scaleY);
}

// ─── CHART TOOLTIP INTERACTION ─────────────────────────────────────────────
function setupChartTooltips(svg, dates, bBals, pBals, minB, curr, eventsLog, scaleX, scaleY) {
    const tooltip = document.getElementById('chartTooltip');
    const container = document.getElementById('chartContainer');
    if (!container || !tooltip) return;

    container.onmousemove = (e) => {
        const rect = container.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const normX = (mouseX / rect.width) * 1000;

        let bestIdx = 0;
        let bestDist = 999999;
        for (let i = 0; i < dates.length; i++) {
            const dX = Math.abs(scaleX(i) - normX);
            if (dX < bestDist) {
                bestDist = dX;
                bestIdx = i;
            }
        }

        const dateStr = dates[bestIdx];
        const baseBal = bBals[bestIdx];
        const planBal = pBals[bestIdx];
        const dayEvents = eventsLog[dateStr] || [];

        let eventsHtml = '';
        if (dayEvents.length > 0) {
            eventsHtml = `
                <div style="margin-top:6px; padding-top:6px; border-top:1px dashed #E2E8F0; font-size:11px; color:#0EA5E9;">
                    ${dayEvents.map(ev => `• ${ev.desc || ev.category || 'Event'}: ${curr} ${formatNumber(ev.amount)}`).join('<br>')}
                </div>
            `;
        }

        tooltip.innerHTML = `
            <div style="font-weight:700; color:#17324D; margin-bottom:4px;">${dateStr}</div>
            <div style="color:#6256D9;">Normal: <strong>${curr} ${formatNumber(baseBal)}</strong></div>
            <div style="color:#35B88A;">With Plan: <strong>${curr} ${formatNumber(planBal)}</strong></div>
            <div style="color:#E9A83B; font-size:11px;">Buffer Floor: ${curr} ${formatNumber(minB)}</div>
            ${eventsHtml}
        `;
        tooltip.style.display = 'block';
        tooltip.style.left = `${Math.min(rect.width - 210, Math.max(10, mouseX + 12))}px`;
        tooltip.style.top = `${Math.min(rect.height - 110, Math.max(10, e.clientY - rect.top - 20))}px`;
    };

    container.onmouseleave = () => {
        tooltip.style.display = 'none';
    };
}

// ─── RENDER AI INSIGHT PANEL ───────────────────────────────────────────────
function renderAiInsight(pred, prof, curr) {
    const el = document.getElementById('aiInsightBody');
    if (!el) return;

    const headroom = prof.current_available_balance - prof.minimum_balance_to_keep;
    let text = pred.decision_explanation;

    if (pred.affordability_status === 'affordable_now') {
        text += ` Your available liquid balance provides ${curr} ${formatNumber(headroom)} of discretionary headroom above your protected minimum safety buffer.`;
    } else if (pred.affordability_status === 'affordable_later') {
        text += ` A temporary hold preserves your ${curr} ${formatNumber(prof.minimum_balance_to_keep)} emergency cushion until confirmed salary arrives.`;
    }

    el.textContent = text;
}

// ─── WHAT-IF SIMULATOR INTERACTION ─────────────────────────────────────────
function setupSimulatorSync() {
    const slider = document.getElementById('simAmountSlider');
    const input = document.getElementById('simAmountInput');
    const display = document.getElementById('simAmountDisplay');
    const incomeSlider = document.getElementById('simIncomeSlider');
    const incomeDisplay = document.getElementById('simIncomeDisplay');

    if (slider && input && display) {
        slider.addEventListener('input', (e) => {
            input.value = e.target.value;
            display.textContent = `₹${formatNumber(e.target.value)}`;
        });
        input.addEventListener('input', (e) => {
            slider.value = e.target.value;
            display.textContent = `₹${formatNumber(e.target.value)}`;
        });
    }

    if (incomeSlider && incomeDisplay) {
        incomeSlider.addEventListener('input', (e) => {
            const val = parseInt(e.target.value, 10);
            const sign = val > 0 ? '+' : '';
            incomeDisplay.textContent = `${sign}₹${formatNumber(val)}`;
        });
    }
}

function syncSimulatorWithRequest(req, curr) {
    const slider = document.getElementById('simAmountSlider');
    const input = document.getElementById('simAmountInput');
    const display = document.getElementById('simAmountDisplay');

    if (slider && input && display && req) {
        const amt = Math.round(req.requested_amount);
        slider.max = Math.max(150000, amt * 2);
        slider.value = amt;
        input.value = amt;
        display.textContent = `${curr} ${formatNumber(amt)}`;
    }
}

function toggleCategoryChip(checkbox) {
    const chip = checkbox.closest('.cat-check-chip');
    if (chip) {
        chip.classList.toggle('checked', checkbox.checked);
    }
}

async function runSimulator() {
    if (!currentRequestData) return;
    const req = currentRequestData.request;
    const simAmount = parseFloat(document.getElementById('simAmountInput').value) || req.requested_amount;

    // Collect spending changes
    const changes = {};
    if (document.getElementById('catDining') && document.getElementById('catDining').checked) {
        changes['dining'] = 'reduce';
    }
    if (document.getElementById('catShopping') && document.getElementById('catShopping').checked) {
        changes['shopping'] = 'reduce';
    }
    if (document.getElementById('catSubs') && document.getElementById('catSubs').checked) {
        changes['subscriptions'] = 'stop';
    }
    if (document.getElementById('catTransport') && document.getElementById('catTransport').checked) {
        changes['transport'] = 'reduce';
    }

    const payload = {
        user_id: req.user_id,
        request_date: req.request_date,
        requested_amount: simAmount,
        desired_completion_date: req.desired_completion_date,
        allows_partial_payment: req.allows_partial_payment,
        spending_changes: changes
    };

    const res = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    const data = await res.json();
    const pred = data.prediction;

    const statusEl = document.getElementById('simResultStatus');
    const expEl = document.getElementById('simResultExplanation');

    statusEl.textContent = `${formatStatus(pred.affordability_status)} (${formatMethod(pred.recommended_payment_method)})`;
    statusEl.style.color = pred.affordability_status === 'affordable_now' ? 'var(--emerald)' : (pred.affordability_status === 'not_affordable' ? 'var(--rose)' : 'var(--amber)');
    expEl.textContent = pred.decision_explanation;
}

// ─── MULTIMODAL DOCUMENT VIEWER ────────────────────────────────────────────
function selectDocument(imageId) {
    currentDocImage = imageId;
    const doc = DOCUMENT_DATA[imageId];
    if (!doc) return;

    // Update buttons
    document.querySelectorAll('.doc-thumb-btn').forEach(btn => {
        btn.classList.toggle('active', btn.textContent.includes(imageId));
    });

    const imgEl = document.getElementById('docPreviewImg');
    if (imgEl) imgEl.src = doc.url;

    const merchantEl = document.getElementById('docMerchant');
    if (merchantEl) merchantEl.textContent = doc.merchant;

    const dateEl = document.getElementById('docDate');
    if (dateEl) dateEl.textContent = doc.date;

    const amtEl = document.getElementById('docTotalAmount');
    if (amtEl) amtEl.textContent = `${doc.currency} ${formatNumber(doc.amount)}`;

    const eventEl = document.getElementById('docEventId');
    if (eventEl) eventEl.textContent = doc.event_id;

    const userEl = document.getElementById('docUserId');
    if (userEl) userEl.textContent = `${doc.user_id} (${doc.request_id})`;
}

function openDocumentFullModal() {
    const doc = DOCUMENT_DATA[currentDocImage];
    if (!doc) return;

    const modal = document.getElementById('docEnlargeModal');
    const title = document.getElementById('modalDocTitle');
    const img = document.getElementById('modalEnlargedImg');

    if (title) title.textContent = `${doc.merchant} — ${doc.currency} ${formatNumber(doc.amount)} (${doc.image_id})`;
    if (img) img.src = doc.url;
    if (modal) modal.classList.add('open');
}

// ─── BREAKDOWN MODAL ───────────────────────────────────────────────────────
function openBreakdownModal() {
    if (!currentRequestData) return;
    const prof = currentRequestData.profile;
    const curr = prof.home_currency || 'INR';

    const modal = document.getElementById('breakdownModal');
    const body = document.getElementById('breakdownModalBody');

    body.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:16px;">
            <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:12px;">
                <div style="background:var(--bg-page); padding:12px; border-radius:8px;">
                    <div style="font-size:11px; color:var(--text-secondary); text-transform:uppercase;">Available Cash</div>
                    <div style="font-size:16px; font-weight:700; color:var(--text-primary);">${curr} ${formatNumber(prof.current_available_balance)}</div>
                </div>
                <div style="background:var(--bg-page); padding:12px; border-radius:8px;">
                    <div style="font-size:11px; color:var(--text-secondary); text-transform:uppercase;">Minimum Buffer</div>
                    <div style="font-size:16px; font-weight:700; color:var(--amber);">${curr} ${formatNumber(prof.minimum_balance_to_keep)}</div>
                </div>
                <div style="background:var(--bg-page); padding:12px; border-radius:8px;">
                    <div style="font-size:11px; color:var(--text-secondary); text-transform:uppercase;">Monthly Salary</div>
                    <div style="font-size:16px; font-weight:700; color:var(--emerald);">${curr} ${formatNumber(prof.monthly_salary)}</div>
                </div>
            </div>

            <div>
                <strong style="font-size:13px; color:var(--text-primary);">Protected Categories:</strong>
                <div style="margin-top:6px; font-size:13px; color:var(--text-secondary);">
                    ${(prof.expense_categories_to_protect || 'None').split('|').map(t => `<span style="display:inline-block; background:var(--bg-page); padding:3px 8px; border-radius:4px; margin-right:6px;">🛡️ ${t}</span>`).join('')}
                </div>
            </div>

            <div>
                <strong style="font-size:13px; color:var(--text-primary);">Willing to Reduce / Adjust:</strong>
                <div style="margin-top:6px; font-size:13px; color:var(--text-secondary);">
                    ${(prof.expense_categories_user_is_willing_to_reduce || 'None').split('|').map(t => `<span style="display:inline-block; background:var(--bg-page); padding:3px 8px; border-radius:4px; margin-right:6px;">✂️ ${t}</span>`).join('')}
                </div>
            </div>
        </div>
    `;
    modal.classList.add('open');
}

// ─── REQUESTS TABLE RENDERING & FILTERING ──────────────────────────────────
function renderRequestsTable(list) {
    const tbody = document.getElementById('requestsTableBody');
    if (!tbody) return;

    if (list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted);">No requests match the current filter.</td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(r => {
        const isSample = r.is_sample;
        const statusClass = r.affordability_status;
        const statusLabel = formatStatus(r.affordability_status);
        const methodLabel = formatMethod(r.recommended_payment_method);
        const sampleTag = isSample ? '<span style="font-size:10px; background:var(--indigo-light); color:var(--indigo); padding:2px 6px; border-radius:4px; margin-left:4px; font-weight:700;">SAMPLE</span>' : '';

        return `
            <tr data-id="${r.request_id}" onclick="loadRequestDetail('${r.request_id}')">
                <td><strong>${r.request_id}</strong> ${sampleTag}</td>
                <td>${r.user_id}</td>
                <td>${r.request_date}</td>
                <td style="max-width:280px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${escapeHtml(r.request_text)}">${escapeHtml(r.request_text)}</td>
                <td><strong>₹${formatNumber(r.requested_amount)}</strong></td>
                <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
                <td>${methodLabel}</td>
                <td>
                    <button class="btn btn-outline" style="height:28px; padding:0 10px; font-size:11px;" onclick="event.stopPropagation(); loadRequestDetail('${r.request_id}')">
                        Inspect →
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function setTableFilter(filter, btn) {
    currentFilter = filter;
    document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
    if (btn) btn.classList.add('active');
    applyCombinedFilters();
}

function setupSearchListeners() {
    const searchInput = document.getElementById('globalSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            applyCombinedFilters();
        });
    }
}

function applyCombinedFilters() {
    const q = (document.getElementById('globalSearchInput')?.value || '').toLowerCase();

    const filtered = allRequests.filter(r => {
        const matchSearch = r.request_id.toLowerCase().includes(q) ||
                            r.user_id.toLowerCase().includes(q) ||
                            r.request_text.toLowerCase().includes(q);

        let matchStatus = true;
        if (currentFilter === 'sample') {
            matchStatus = r.is_sample;
        } else if (currentFilter !== 'all') {
            matchStatus = r.affordability_status === currentFilter;
        }

        return matchSearch && matchStatus;
    });

    renderRequestsTable(filtered);
}

// ─── NAVIGATION SCROLLING ──────────────────────────────────────────────────
function navigateToSection(sectionId) {
    document.querySelectorAll('.sidebar-nav .nav-item').forEach(b => b.classList.remove('active'));
    
    if (sectionId === 'dashboard') {
        document.getElementById('navDashboard')?.classList.add('active');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (sectionId === 'requests') {
        document.getElementById('navRequests')?.classList.add('active');
        document.getElementById('requestsSection')?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'simulator') {
        document.getElementById('navSimulator')?.classList.add('active');
        document.getElementById('simulatorSection')?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'documents') {
        document.getElementById('navDocuments')?.classList.add('active');
        document.getElementById('documentsSection')?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'analytics') {
        document.getElementById('navAnalytics')?.classList.add('active');
        document.getElementById('analyticsSection')?.scrollIntoView({ behavior: 'smooth' });
    }
}

// ─── AI CHAT ASSISTANT DRAWER ──────────────────────────────────────────────
function toggleChatDrawer() {
    const drawer = document.getElementById('chatDrawer');
    if (drawer) drawer.classList.toggle('open');
}

function prefillChat(text) {
    const input = document.getElementById('chatDrawerInput');
    if (input) {
        input.value = text;
        input.focus();
    }
}

async function sendChatFromDrawer() {
    const input = document.getElementById('chatDrawerInput');
    const msg = input.value.trim();
    if (!msg) return;

    const msgsContainer = document.getElementById('chatMessages');

    // Add user bubble
    const userBubble = document.createElement('div');
    userBubble.className = 'chat-bubble user';
    userBubble.textContent = msg;
    msgsContainer.appendChild(userBubble);
    input.value = '';
    msgsContainer.scrollTop = msgsContainer.scrollHeight;

    // Typing indicator
    const typingBubble = document.createElement('div');
    typingBubble.className = 'chat-bubble agent';
    typingBubble.textContent = 'Analyzing cash flow trajectory...';
    msgsContainer.appendChild(typingBubble);
    msgsContainer.scrollTop = msgsContainer.scrollHeight;

    try {
        const uId = currentRequestData ? currentRequestData.request.user_id : 'user_01';
        const resp = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: msg, user_id: uId })
        });
        const resData = await resp.json();
        typingBubble.remove();

        const agentBubble = document.createElement('div');
        agentBubble.className = 'chat-bubble agent';

        if (resData.type === 'follow_up') {
            agentBubble.textContent = resData.question;
        } else {
            agentBubble.innerHTML = `
                <div>${escapeHtml(resData.reply)}</div>
                ${resData.prediction ? `<div style="margin-top:6px; font-weight:700; color:var(--emerald);">✓ Status: ${formatStatus(resData.prediction.affordability_status)}</div>` : ''}
            `;
        }
        msgsContainer.appendChild(agentBubble);
        msgsContainer.scrollTop = msgsContainer.scrollHeight;
    } catch(err) {
        typingBubble.remove();
        const errBubble = document.createElement('div');
        errBubble.className = 'chat-bubble agent';
        errBubble.style.color = 'var(--rose)';
        errBubble.textContent = `Error: ${err.message}`;
        msgsContainer.appendChild(errBubble);
    }
}

// ─── RECEIPT SCANNER & OCR ─────────────────────────────────────────────────
function triggerReceiptScan() {
    document.getElementById('receiptFileInput')?.click();
}

function handleReceiptFile(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
        const base64 = e.target.result.split(',')[1];
        try {
            const resp = await fetch('/api/ocr_receipt', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ image_base64: base64 })
            });
            const res = await resp.json();
            if (res.amount) {
                prefillChat(`Can I afford to pay ${res.currency || '₹'} ${res.amount} for ${res.merchant || 'receipt item'}?`);
            }
        } catch(e) {
            console.error("OCR scan error:", e);
        }
    };
    reader.readAsDataURL(file);
    event.target.value = '';
}

// ─── CONNECT BANK MODAL ────────────────────────────────────────────────────
function connectBank() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay open';
    modal.id = 'bankModalOverlay';
    modal.innerHTML = `
        <div class="modal-card">
            <div class="modal-header-clean">
                <strong>Connect Your Bank Account</strong>
                <button class="modal-close-btn" onclick="document.getElementById('bankModalOverlay').remove()">&times;</button>
            </div>
            <div class="modal-body-clean" style="display:flex; flex-direction:column; gap:16px;">
                <p style="font-size:13px; color:var(--text-secondary);">
                    Connect live account data to synchronize your real balances and recurring commitments into the 90-day predictive engine.
                </p>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                    <button class="btn btn-outline" style="height:48px; border-radius:12px;" onclick="useMockBank()">
                        🧪 Live Demo Sandbox
                    </button>
                    <button class="btn btn-primary" style="height:48px; border-radius:12px;" onclick="initPlaid()">
                        🏦 Plaid Link (OAuth)
                    </button>
                </div>
            </div>
        </div>
    `;
    modal.onclick = (e) => { if (e.target === modal) modal.remove(); };
    document.body.appendChild(modal);
}

async function useMockBank() {
    document.getElementById('bankModalOverlay')?.remove();
    alert("✓ Mock Bank Profile Connected! Recurring salary and commitments synchronized.");
}

function initPlaid() {
    document.getElementById('bankModalOverlay')?.remove();
    alert("ℹ️ Plaid OAuth initialized. Set PLAID_CLIENT_ID & PLAID_SECRET for live institution connection.");
}

// ─── UTILITIES & FORMATTING ────────────────────────────────────────────────
function formatNumber(num) {
    if (num === null || num === undefined) return '-';
    return Number(num).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatCompact(num) {
    if (Math.abs(num) >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (Math.abs(num) >= 1000) return (num / 1000).toFixed(0) + 'k';
    return Number(num).toFixed(0);
}

function formatDateShort(dateStr) {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) {
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const mIdx = parseInt(parts[1], 10) - 1;
        return `${parseInt(parts[2], 10)} ${monthNames[mIdx] || ''}`;
    }
    return dateStr;
}

function formatStatus(status) {
    const map = {
        'affordable_now': 'Affordable Now',
        'affordable_with_plan': 'Affordable With Plan',
        'affordable_later': 'Wait for Salary',
        'not_affordable': 'Not Affordable'
    };
    return map[status] || status;
}

function formatMethod(method) {
    const map = {
        'full_payment': 'Full Payment',
        'partial_payment': 'Partial Payment',
        'installments': 'Installments',
        'wait': 'Wait',
        'not_recommended': 'Not Recommended'
    };
    return map[method] || method;
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
